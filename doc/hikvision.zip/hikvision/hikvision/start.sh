#!/bin/bash

# 读取配置文件
config_file=config.conf
# 读取配置
config_datas=$(cat $config_file)

# 配置文件中读取配置
get_config() {
    skey=$1
    echo "$config_datas"|grep -E "^$skey="|sed "s/$skey=//g"
}

hikvision_device=$(get_config 'hikvision.device')
data_save_path=$(get_config 'data.save.path')
export_url=$(get_config 'export.url')
spring_redis_host=$(get_config 'spring.redis.host')
spring_redis_port=$(get_config 'spring.redis.port')
jre_bin=$(get_config 'jrebin')
runtime=$(get_config 'runtime')
hikvision_config_location=$(get_config 'hikvision.config.location')

current_path=$(cd `dirname $0`; pwd)

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:${current_path}/lib/HCNetSDKCom

nohup ${jre_bin}java -jar hikvision-0.0.1-SNAPSHOT.jar --hikvision.device=${hikvision_device} --data.save.path=${data_save_path} --export.url=${export_url} --spring.redis.host=${spring_redis_host} --spring.redis.port=${spring_redis_port} --runtime=${runtime} --hikvision.config.location=${hikvision_config_location} > ${hikvision_device}.log 2>&1 &
